package com.nuvio.tv.ui.navigation

import kotlinx.coroutines.launch
import com.nuvio.tv.ui.theme.NuvioMotion
import com.nuvio.tv.ui.components.PlaybackAvailabilityProvider
import com.nuvio.tv.ui.components.LocalPlaybackAvailability
import com.nuvio.tv.ui.components.canStream
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import com.nuvio.tv.R

import androidx.compose.animation.core.tween
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import com.nuvio.tv.livetv.ondemand.settingsOnly
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.nuvio.tv.core.build.AppFeaturePolicy
import com.nuvio.tv.core.party.PartyMedia
import com.nuvio.tv.domain.model.ExperienceMode
import com.nuvio.tv.data.mediaserver.ServerCatalog
import com.nuvio.tv.ui.screens.CatalogSeeAllScreen
import com.nuvio.tv.ui.screens.ExperienceModeSelectionScreen
import com.nuvio.tv.ui.screens.LayoutSelectionScreen
import com.nuvio.tv.ui.screens.detail.MetaDetailsScreen
import com.nuvio.tv.ui.screens.home.HomeScreen
import com.nuvio.tv.ui.screens.addon.AddonManagerScreen
import com.nuvio.tv.ui.screens.addon.CatalogOrderScreen
import com.nuvio.tv.ui.screens.library.LibraryScreen
import com.nuvio.tv.ui.screens.player.PlayerExitReason
import com.nuvio.tv.ui.screens.player.PlayerScreen
import com.nuvio.tv.ui.screens.player.PostPlayRecommendation
import com.nuvio.tv.ui.screens.player.playerBackOpensCurrentEpisodeStreams
import com.nuvio.tv.ui.screens.party.PartyScreen
import com.nuvio.tv.ui.screens.plugin.PluginScreen
import com.nuvio.tv.ui.screens.search.DiscoverScreen
import com.nuvio.tv.ui.screens.search.SearchScreen
import com.nuvio.tv.ui.screens.settings.AboutScreen
import com.nuvio.tv.ui.screens.settings.LayoutSettingsScreen
import com.nuvio.tv.ui.screens.settings.LicensesAttributionsScreen
import com.nuvio.tv.ui.screens.settings.PlaybackSettingsScreen
import com.nuvio.tv.ui.screens.settings.SettingsScreen
import com.nuvio.tv.ui.screens.settings.SupportersContributorsScreen
import com.nuvio.tv.ui.screens.settings.ThemeSettingsScreen
import com.nuvio.tv.ui.screens.settings.TrackingSettingsScreen
import com.nuvio.tv.ui.screens.settings.TmdbSettingsScreen
import com.nuvio.tv.ui.screens.stream.StreamScreen
import com.nuvio.tv.ui.screens.home.ContinueWatchingItem
import com.nuvio.tv.ui.screens.account.AuthQrSignInScreen
import com.nuvio.tv.ui.screens.cast.CastDetailScreen
import com.nuvio.tv.ui.screens.profile.ProfileSelectionMode
import com.nuvio.tv.ui.screens.profile.ProfileSelectionScreen
import com.nuvio.tv.ui.screens.tmdb.TmdbEntityBrowseScreen
import com.nuvio.tv.ui.screens.home.HeroBackdropState

@Composable
fun NuvioNavHost(
    navController: NavHostController,
    startDestination: String = Screen.Home.route,
    hideBuiltInHeaders: Boolean = false
) {
    PlaybackAvailabilityProvider {
        // The NavController keeps its back stack ViewModels in the store of the owner it is
        // composed under, so use the session store when MainActivity provides one.
        val navViewModelStoreOwner = LocalNavViewModelStoreOwner.current
            ?: checkNotNull(LocalViewModelStoreOwner.current)
        CompositionLocalProvider(LocalViewModelStoreOwner provides navViewModelStoreOwner) {
            PlaybackNavHost(navController, startDestination, hideBuiltInHeaders)
        }
    }
    // Live TV fork: "Remind me" messages, shown on top of whatever screen you're on.
    com.nuvio.tv.livetv.reminders.LiveTvReminderHost(navController)
    // Live TV fork: "Loading channels… / Importing movies…" pill while things download.
    com.nuvio.tv.livetv.ui.LiveTvLoadingHost(navController)
    // Live TV fork: Sports reminders and scoring alerts, on top of whatever screen you're on.
    com.nuvio.tv.livetv.sports.SportsHost(navController)
}

@Composable
private fun PlaybackNavHost(
    navController: NavHostController,
    startDestination: String,
    hideBuiltInHeaders: Boolean
) {
    val playbackAvailability = LocalPlaybackAvailability.current
    val context = LocalContext.current
    fun isStreamToPlayer(from: String, to: String): Boolean {
        return from.startsWith("stream/") && to.startsWith("player/")
    }

    fun isPlayerToStream(from: String, to: String): Boolean {
        return from.startsWith("player/") && to.startsWith("stream/")
    }

    fun openPartyMedia(media: PartyMedia) {
        if (navController.currentDestination?.route?.startsWith("player/") == true) navController.popBackStack()
        navController.navigate(
            Screen.Stream.createRoute(
                videoId = media.videoId ?: media.metaId,
                contentType = media.type,
                title = media.title,
                poster = media.poster,
                backdrop = media.background,
                logo = media.logo,
                season = media.season,
                episode = media.episode,
                episodeName = media.episodeTitle,
                contentId = media.metaId,
                contentName = media.title,
                manualSelection = true
            )
        )
    }

    NavHost(
        navController = navController,
        startDestination = startDestination,
        enterTransition = {
            val from = initialState.destination.route.orEmpty()
            val to = targetState.destination.route.orEmpty()
            val isAutoPlayNav = targetState.arguments
                ?.getString("autoPlayNav")
                ?.toBooleanStrictOrNull() == true
            if (isStreamToPlayer(from, to) && isAutoPlayNav) {
                EnterTransition.None
            } else {
                fadeIn(animationSpec = tween(NuvioMotion.tokens.durations.medium))
            }
        },
        exitTransition = {
            val from = initialState.destination.route.orEmpty()
            val to = targetState.destination.route.orEmpty()
            val isAutoPlayNav = targetState.arguments
                ?.getString("autoPlayNav")
                ?.toBooleanStrictOrNull() == true
            if (isStreamToPlayer(from, to) && isAutoPlayNav) {
                ExitTransition.None
            } else {
                fadeOut(animationSpec = tween(NuvioMotion.tokens.durations.medium))
            }
        },
        popEnterTransition = {
            val from = initialState.destination.route.orEmpty()
            val to = targetState.destination.route.orEmpty()
            val isAutoPlayNav = initialState.arguments
                ?.getString("autoPlayNav")
                ?.toBooleanStrictOrNull() == true
            if (isPlayerToStream(from, to) && isAutoPlayNav) {
                EnterTransition.None
            } else {
                fadeIn(animationSpec = tween(NuvioMotion.tokens.durations.medium))
            }
        },
        popExitTransition = {
            val from = initialState.destination.route.orEmpty()
            val to = targetState.destination.route.orEmpty()
            val isAutoPlayNav = initialState.arguments
                ?.getString("autoPlayNav")
                ?.toBooleanStrictOrNull() == true
            if (isPlayerToStream(from, to) && isAutoPlayNav) {
                ExitTransition.None
            } else {
                fadeOut(animationSpec = tween(NuvioMotion.tokens.durations.medium))
            }
        }
    ) {
        composable(Screen.ExperienceModeSelection.route) {
            ExperienceModeSelectionScreen(
                onContinue = { mode ->
                    val destination = if (mode == ExperienceMode.ESSENTIAL) {
                        Screen.Home.route
                    } else {
                        Screen.LayoutSelection.route
                    }
                    navController.navigate(destination) {
                        popUpTo(Screen.ExperienceModeSelection.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.LayoutSelection.route) {
            LayoutSelectionScreen(
                onContinue = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.LayoutSelection.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Home.route) {
            // Live TV fork: back from On Demand, Home starts from its own hero backdrop.
            com.nuvio.tv.livetv.ondemand.OnDemandBackdropGuard.restoreForHome()
            // Live TV fork: keep Home's latest layout settings for the On Demand page.
            // Collected in the background, never read while drawing: reading it here made the
            // whole Home page rebuild on every change (scrolling, posters, trailers).
            run {
                val homeVmForSettings: com.nuvio.tv.ui.screens.home.HomeViewModel = androidx.hilt.navigation.compose.hiltViewModel()
                androidx.compose.runtime.LaunchedEffect(homeVmForSettings) {
                    homeVmForSettings.uiState.collect { com.nuvio.tv.livetv.ondemand.OnDemandHomeSettings.last = it }
                }
            }
            fun createContinueWatchingRoute(
                item: ContinueWatchingItem,
                manualSelection: Boolean = false,
                startFromBeginning: Boolean = false
            ): String {
                return when (item) {
                    is ContinueWatchingItem.InProgress -> Screen.Stream.createRoute(
                        videoId = item.progress.videoId,
                        contentType = item.progress.contentType,
                        title = item.progress.name,
                        poster = item.progress.poster,
                        backdrop = item.progress.backdrop,
                        logo = item.progress.logo,
                        season = item.progress.season,
                        episode = item.progress.episode,
                        episodeName = item.progress.episodeTitle,
                        genres = null,
                        year = null,
                        contentId = item.progress.contentId,
                        contentName = item.progress.name,
                        runtime = null,
                        manualSelection = manualSelection,
                        returnToDetailOnBack = item.progress.contentType.equals("series", ignoreCase = true),
                        returnToHomeOnBack = true,
                        startFromBeginning = startFromBeginning,
                        contentLanguage = item.contentLanguage
                    )
                    is ContinueWatchingItem.NextUp -> Screen.Stream.createRoute(
                        videoId = item.info.videoId,
                        contentType = item.info.contentType,
                        title = item.info.name,
                        poster = item.info.poster,
                        backdrop = item.info.backdrop,
                        logo = item.info.logo,
                        season = item.info.season,
                        episode = item.info.episode,
                        episodeName = item.info.episodeTitle,
                        genres = null,
                        year = null,
                        contentId = item.info.contentId,
                        contentName = item.info.name,
                        runtime = null,
                        manualSelection = manualSelection,
                        returnToDetailOnBack = item.info.contentType.equals("series", ignoreCase = true),
                        returnToHomeOnBack = true,
                        startFromBeginning = startFromBeginning,
                        contentLanguage = item.info.contentLanguage
                    )
                }
            }

            // Live TV fork: get Live TV ready in the background, so the guide is there when opened.
            androidx.compose.runtime.LaunchedEffect(Unit) {
                runCatching { com.nuvio.tv.livetv.startup.LiveTvPreload.start(context) }
            }
            // Live TV fork: what the home screen's Live TV row opens.
            val openLiveTv = {
                navController.navigate(Screen.LiveTv.route) {
                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }
            androidx.compose.runtime.CompositionLocalProvider(
                com.nuvio.tv.livetv.home.LocalLiveTvHomeActions provides com.nuvio.tv.livetv.home.LiveTvHomeActions(
                    onHome = true,
                    openFullscreen = {
                        openLiveTv()
                        navController.navigate(Screen.LiveTvPlayer.route) { launchSingleTop = true }
                    },
                    openGuide = { openLiveTv() }
                )
            ) {
            HomeScreen(
                onNavigateToDetail = { itemId, itemType, addonBaseUrl ->
                    val heroBackdrop = HeroBackdropState.consumeAndClear()
                    navController.navigate(
                        Screen.Detail.createRoute(
                            itemId = itemId,
                            itemType = itemType,
                            addonBaseUrl = addonBaseUrl,
                            heroBackdropUrl = heroBackdrop
                        )
                    )
                },
                onContinueWatchingClick = onContinueWatchingClick@{ item ->
                    if (!playbackAvailability.canStream(item)) {
                        Toast.makeText(context, R.string.playback_unavailable_message, Toast.LENGTH_SHORT).show()
                        return@onContinueWatchingClick
                    }
                    navController.navigate(createContinueWatchingRoute(item))
                },
                onContinueWatchingStartFromBeginning = onContinueWatchingStartFromBeginning@{ item ->
                    if (!playbackAvailability.canStream(item)) {
                        Toast.makeText(context, R.string.playback_unavailable_message, Toast.LENGTH_SHORT).show()
                        return@onContinueWatchingStartFromBeginning
                    }
                    navController.navigate(
                        createContinueWatchingRoute(item, startFromBeginning = true)
                    )
                },
                onContinueWatchingPlayManually = onContinueWatchingPlayManually@{ item ->
                    if (!playbackAvailability.canStream(item)) {
                        Toast.makeText(context, R.string.playback_unavailable_message, Toast.LENGTH_SHORT).show()
                        return@onContinueWatchingPlayManually
                    }
                    navController.navigate(
                        createContinueWatchingRoute(item, manualSelection = true)
                    )
                },
                onNavigateToCatalogSeeAll = { catalogId, addonId, type ->
                    navController.navigate(Screen.CatalogSeeAll.createRoute(catalogId, addonId, type))
                },
                onNavigateToFolderDetail = { collectionId, folderId ->
                    navController.navigate(Screen.FolderDetail.createRoute(collectionId, folderId))
                }
            )
            }
        }

        composable(
            route = Screen.Detail.route,
            arguments = listOf(
                navArgument("itemId") { type = NavType.StringType },
                navArgument("itemType") { type = NavType.StringType },
                navArgument("addonBaseUrl") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("returnFocusSeason") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("returnFocusEpisode") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("returnToHomeOnBack") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("heroBackdropUrl") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("playOnLoad") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("manualSelection") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                }
            )
        ) { backStackEntry ->
            val detailArgs = backStackEntry.arguments
            if (ServerCatalog.isCollection(detailArgs?.getString("itemId"), detailArgs?.getString("itemType"))) {
                ServerCatalogDestination(navController, backStackEntry)
                return@composable
            }
            val savedState = backStackEntry.savedStateHandle
            val returnToHomeOnBack = detailArgs
                ?.getString("returnToHomeOnBack")
                ?.toBooleanStrictOrNull() == true
            val returnFocusSeason by savedState.getStateFlow(
                "returnFocusSeason", detailArgs?.getString("returnFocusSeason")?.toIntOrNull()
            ).collectAsState()
            val returnFocusEpisode by savedState.getStateFlow(
                "returnFocusEpisode", detailArgs?.getString("returnFocusEpisode")?.toIntOrNull()
            ).collectAsState()
            val heroRestoreToken by savedState.getStateFlow(
                "heroRestoreToken", 0
            ).collectAsState()
            val heroBackdropUrl = detailArgs?.getString("heroBackdropUrl")?.takeIf { it.isNotBlank() }
            val playOnLoad = detailArgs?.getString("playOnLoad")?.toBooleanStrictOrNull() == true
            val manualSelection = detailArgs?.getString("manualSelection")?.toBooleanStrictOrNull() == true
            val onDemandScope = androidx.compose.runtime.rememberCoroutineScope()
            var onDemandVersions by androidx.compose.runtime.remember {
                androidx.compose.runtime.mutableStateOf<List<com.nuvio.tv.livetv.ondemand.OnDemandRepository.Version>?>(null)
            }
            var onDemandPlayVersion by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<(String) -> Unit>({}) }
            onDemandVersions?.let { versions ->
                com.nuvio.tv.livetv.ondemand.OnDemandVersionPicker(
                    versions = versions,
                    onPick = { v -> onDemandVersions = null; onDemandPlayVersion(v.item.uid) },
                    onDismiss = { onDemandVersions = null }
                )
            }
            DetailChildHost(parentNavController = navController) { childNav ->
            MetaDetailsScreen(
                returnFocusSeason = returnFocusSeason,
                returnFocusEpisode = returnFocusEpisode,
                heroRestoreToken = heroRestoreToken,
                heroBackdropUrl = heroBackdropUrl,
                playOnLoad = playOnLoad,
                playOnLoadManually = manualSelection,
                onReturnFocusConsumed = {
                    savedState["returnFocusSeason"] = null
                    savedState["returnFocusEpisode"] = null
                },
                onBackPress = {
                    if (returnToHomeOnBack) {
                        val popped = navController.popBackStack(Screen.Home.route, inclusive = false)
                        if (!popped) {
                            navController.navigate(Screen.Home.route) {
                                launchSingleTop = true
                            }
                        }
                    } else {
                        navController.popBackStack()
                    }
                },
                onNavigateToCastDetail = { personId, personName, preferCrew ->
                    childNav.navigate(Screen.CastDetail.createRoute(personId, personName, preferCrew))
                },
                onNavigateToTmdbEntityBrowse = { entityKind, entityId, entityName, sourceType ->
                    childNav.navigate(
                        Screen.TmdbEntityBrowse.createRoute(
                            entityKind = entityKind,
                            entityId = entityId,
                            entityName = entityName,
                            sourceType = sourceType
                        )
                    )
                },
                onNavigateToDetail = { itemId, itemType, addonBaseUrl ->
                    childNav.navigateNestedDetail(itemId, itemType, addonBaseUrl)
                },
                onPlayClick = { videoId, contentType, contentId, title, poster, backdrop, logo, season, episode, episodeName, genres, year, runtime, contentLanguage ->
                  // Live TV fork: Play shows every source, also for titles opened from On Demand.
                  val onDemandUid = savedState.get<String>(com.nuvio.tv.livetv.ondemand.OnDemandPlay.KEY)
                  val openStreams = {
                    navController.navigate(
                        Screen.Stream.createRoute(
                            videoId = videoId,
                            contentType = contentType,
                            title = title,
                            poster = poster,
                            backdrop = backdrop,
                            logo = logo,
                            season = season,
                            episode = episode,
                            episodeName = episodeName,
                            genres = genres,
                            year = year,
                            contentId = contentId,
                            contentName = title,
                            runtime = runtime,
                            returnToDetailOnBack = contentType.equals("series", ignoreCase = true),
                            contentLanguage = contentLanguage
                        )
                    )
                  }
                  fun playVersion(uid: String) = onDemandScope.launch {
                      val resolved = runCatching {
                          com.nuvio.tv.livetv.ondemand.OnDemandPlay.resolve(context, uid, season, episode)
                      }.getOrNull()
                      if (resolved == null) openStreams()
                      else navController.navigate(
                          Screen.Player.createRoute(
                              streamUrl = resolved.url,
                              title = resolved.title,
                              // Everything Nuvio needs to track progress, so it shows up in
                              // Continue Watching (and Trakt / watched marks) like any stream.
                              year = year,
                              contentId = contentId,
                              contentType = contentType,
                              contentName = title,
                              poster = poster ?: resolved.poster,
                              backdrop = backdrop,
                              logo = logo,
                              videoId = videoId,
                              season = season,
                              episode = episode,
                              episodeTitle = episodeName,
                              addonName = com.nuvio.tv.livetv.ondemand.OnDemandStreams.GROUP_NAME,
                              bingeGroup = com.nuvio.tv.livetv.ondemand.OnDemandStreams.BINGE_GROUP,
                              contentLanguage = contentLanguage
                          )
                      )
                  }
                  // Play always shows every source (your addons, debrid and 📡 On Demand), wherever the
                  // title was opened from: one unified list. (The direct-to-provider Play from On
                  // Demand is retired; the provider's copy is in the list as 📡 On Demand.)
                  if (onDemandUid == null || true) openStreams() else onDemandScope.launch {
                      // Several copies (4K / HD, other providers): ask which one.
                      val versions = runCatching {
                          com.nuvio.tv.livetv.ondemand.OnDemandPlay.versions(context, onDemandUid)
                      }.getOrDefault(emptyList())
                      if (versions.size > 1) {
                          onDemandVersions = versions
                          onDemandPlayVersion = { uid -> playVersion(uid) }
                      } else playVersion(onDemandUid)
                  }
                },
                onPlayManuallyClick = { videoId, contentType, contentId, title, poster, backdrop, logo, season, episode, episodeName, genres, year, runtime, contentLanguage ->
                    navController.navigate(
                        Screen.Stream.createRoute(
                            videoId = videoId,
                            contentType = contentType,
                            title = title,
                            poster = poster,
                            backdrop = backdrop,
                            logo = logo,
                            season = season,
                            episode = episode,
                            episodeName = episodeName,
                            genres = genres,
                            year = year,
                            contentId = contentId,
                            contentName = title,
                            runtime = runtime,
                            manualSelection = true,
                            returnToDetailOnBack = contentType.equals("series", ignoreCase = true),
                            contentLanguage = contentLanguage
                        )
                    )
                },
                onPlayStartFromBeginningClick = { videoId, contentType, contentId, title, poster, backdrop, logo, season, episode, episodeName, genres, year, runtime, contentLanguage ->
                    navController.navigate(
                        Screen.Stream.createRoute(
                            videoId = videoId,
                            contentType = contentType,
                            title = title,
                            poster = poster,
                            backdrop = backdrop,
                            logo = logo,
                            season = season,
                            episode = episode,
                            episodeName = episodeName,
                            genres = genres,
                            year = year,
                            contentId = contentId,
                            contentName = title,
                            runtime = runtime,
                            startFromBeginning = true,
                            returnToDetailOnBack = contentType.equals("series", ignoreCase = true),
                            contentLanguage = contentLanguage
                        )
                    )
                }
            )
            }
        }

        composable(
            route = Screen.Stream.route,
            arguments = listOf(
                navArgument("videoId") { type = NavType.StringType },
                navArgument("contentType") { type = NavType.StringType },
                navArgument("title") { type = NavType.StringType },
                navArgument("poster") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("backdrop") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("logo") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("season") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("episode") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("episodeName") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("genres") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("year") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("contentId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("contentName") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("runtime") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("manualSelection") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("returnToDetailOnBack") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("returnToHomeOnBack") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("startFromBeginning") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("contentLanguage") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("profileId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val streamArgs = backStackEntry.arguments
            val streamSavedState = backStackEntry.savedStateHandle
            val restoreSourceSelection by streamSavedState.getStateFlow(
                SOURCE_SELECTION_RESTORE_STATE_KEY, false
            ).collectAsState()
            val returnToDetailOnBack = streamArgs
                ?.getString("returnToDetailOnBack")
                ?.toBooleanStrictOrNull() == true
            val returnToHomeOnBack = streamArgs
                ?.getString("returnToHomeOnBack")
                ?.toBooleanStrictOrNull() == true
            val startFromBeginning = streamArgs
                ?.getString("startFromBeginning")
                ?.toBooleanStrictOrNull() == true
            StreamScreen(
                startFromBeginning = startFromBeginning,
                restoreSourceSelection = restoreSourceSelection,
                onSourceSelectionRestoreHandled = {
                    streamSavedState[SOURCE_SELECTION_RESTORE_STATE_KEY] = false
                },
                onBackPress = {
                    val streamContentType = streamArgs?.getString("contentType").orEmpty()
                    val streamContentId = streamArgs?.getString("contentId").orEmpty()
                    val season = streamArgs?.getString("season")?.toIntOrNull()
                    val episode = streamArgs?.getString("episode")?.toIntOrNull()
                    if (streamContentType.equals("series", ignoreCase = true) && streamContentId.isNotBlank()) {
                        val detailEntry = runCatching { navController.getBackStackEntry(Screen.Detail.route) }.getOrNull()
                        if (detailEntry != null) {
                            detailEntry.savedStateHandle["returnFocusSeason"] = season
                            detailEntry.savedStateHandle["returnFocusEpisode"] = episode
                            navController.popBackStack(Screen.Detail.route, inclusive = false)
                        } else {
                            navController.navigate(
                                Screen.Detail.createRoute(
                                    itemId = streamContentId,
                                    itemType = streamContentType,
                                    addonBaseUrl = null,
                                    returnFocusSeason = season,
                                    returnFocusEpisode = episode,
                                    returnToHomeOnBack = returnToHomeOnBack,
                                    heroBackdropUrl = streamArgs?.getString("backdrop")
                                )
                            ) {
                                popUpTo(Screen.Stream.route) { inclusive = true }
                                launchSingleTop = true
                            }
                        }
                    } else {
                        navController.popBackStack()
                    }
                },
                onStreamSelected = { playbackInfo ->
                    val streamUrl = playbackInfo.url
                        ?: if (playbackInfo.isTorrent) "torrent://${playbackInfo.infoHash}" else null
                    streamUrl?.let { url ->
                        navController.navigate(
                            Screen.Player.createRoute(
                                streamUrl = url,
                                title = playbackInfo.title,
                                streamName = playbackInfo.streamName,
                                year = playbackInfo.year,
                                headers = playbackInfo.headers,
                                contentId = playbackInfo.contentId,
                                contentType = playbackInfo.contentType,
                                contentName = playbackInfo.contentName,
                                poster = playbackInfo.poster,
                                backdrop = playbackInfo.backdrop,
                                logo = playbackInfo.logo,
                                videoId = playbackInfo.videoId,
                                season = playbackInfo.season,
                                episode = playbackInfo.episode,
                                episodeTitle = playbackInfo.episodeTitle,
                                bingeGroup = playbackInfo.bingeGroup,
                                autoPlayNav = false,
                                returnToDetailOnBack = returnToDetailOnBack,
                                returnToHomeOnBack = returnToHomeOnBack,
                                filename = playbackInfo.filename,
                                videoHash = playbackInfo.videoHash,
                                videoSize = playbackInfo.videoSize,
                                startFromBeginning = startFromBeginning,
                                addonName = playbackInfo.addonName,
                                addonLogo = playbackInfo.addonLogo,
                                streamDescription = playbackInfo.streamDescription,
                                infoHash = playbackInfo.infoHash,
                                fileIdx = playbackInfo.fileIdx,
                                sources = playbackInfo.sources,
                                contentLanguage = playbackInfo.contentLanguage,
                                profileId = playbackInfo.profileId,
                                audioDelayMs = playbackInfo.audioDelayMs
                            )
                        )
                    }
                },
                onAutoPlayResolved = { playbackInfo ->
                    val autoPlayUrl = playbackInfo.url
                        ?: if (playbackInfo.isTorrent) "torrent://${playbackInfo.infoHash}" else null
                    autoPlayUrl?.let { url ->
                        navController.navigate(
                            Screen.Player.createRoute(
                                streamUrl = url,
                                title = playbackInfo.title,
                                streamName = playbackInfo.streamName,
                                year = playbackInfo.year,
                                headers = playbackInfo.headers,
                                contentId = playbackInfo.contentId,
                                contentType = playbackInfo.contentType,
                                contentName = playbackInfo.contentName,
                                poster = playbackInfo.poster,
                                backdrop = playbackInfo.backdrop,
                                logo = playbackInfo.logo,
                                videoId = playbackInfo.videoId,
                                season = playbackInfo.season,
                                episode = playbackInfo.episode,
                                episodeTitle = playbackInfo.episodeTitle,
                                bingeGroup = playbackInfo.bingeGroup,
                                autoPlayNav = true,
                                returnToDetailOnBack = returnToDetailOnBack,
                                returnToHomeOnBack = returnToHomeOnBack,
                                filename = playbackInfo.filename,
                                videoHash = playbackInfo.videoHash,
                                videoSize = playbackInfo.videoSize,
                                startFromBeginning = startFromBeginning,
                                addonName = playbackInfo.addonName,
                                addonLogo = playbackInfo.addonLogo,
                                streamDescription = playbackInfo.streamDescription,
                                infoHash = playbackInfo.infoHash,
                                fileIdx = playbackInfo.fileIdx,
                                sources = playbackInfo.sources,
                                contentLanguage = playbackInfo.contentLanguage,
                                profileId = playbackInfo.profileId,
                                audioDelayMs = playbackInfo.audioDelayMs
                            )
                        ) {
                            popUpTo(Screen.Stream.route) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(
            route = Screen.Player.route,
            arguments = listOf(
                navArgument("streamUrl") { type = NavType.StringType },
                navArgument("title") { type = NavType.StringType },
                navArgument("streamName") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("year") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("headers") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("contentId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("contentType") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("contentName") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("poster") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("backdrop") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("logo") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("videoId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("season") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("episode") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("episodeTitle") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("bingeGroup") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("autoPlayNav") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("returnToDetailOnBack") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("returnToHomeOnBack") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("filename") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("videoHash") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("videoSize") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("startFromBeginning") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = "false"
                },
                navArgument("addonName") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("addonLogo") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("streamDescription") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("contentLanguage") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("cloudSessionToken") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("launchStartedAtMs") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("profileId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("audioDelayMs") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            fun popBackToStream(): Boolean {
                val autoPlayNavigation = backStackEntry.arguments
                    ?.getString("autoPlayNav")
                    ?.toBooleanStrictOrNull() == true
                val restoreEntry = navController.previousBackStackEntry?.takeIf { previousEntry ->
                    shouldArmSourceSelectionRestore(
                        autoPlayNavigation = autoPlayNavigation,
                        previousRoute = previousEntry.destination.route
                    )
                }
                val returnedToStream = navController.popBackStack(Screen.Stream.route, inclusive = false)
                if (returnedToStream && restoreEntry != null) {
                    restoreEntry.savedStateHandle[SOURCE_SELECTION_RESTORE_STATE_KEY] = true
                }
                return returnedToStream
            }

            fun navigateFromPostPlay(
                recommendation: PostPlayRecommendation,
                playOnLoad: Boolean,
                manualSelection: Boolean = false
            ) {
                val returnToHomeOnBack = backStackEntry.arguments
                    ?.getString("returnToHomeOnBack")
                    ?.toBooleanStrictOrNull() == true
                val playbackRootRoute = postPlayRecommendationPopUpRoute(
                    navController.previousBackStackEntry?.destination?.route
                )
                navController.navigate(
                    Screen.Detail.createRoute(
                        itemId = recommendation.id,
                        itemType = recommendation.contentType,
                        addonBaseUrl = recommendation.sourceAddonBaseUrl,
                        returnToHomeOnBack = returnToHomeOnBack,
                        heroBackdropUrl = recommendation.backdrop,
                        playOnLoad = playOnLoad,
                        manualSelection = manualSelection
                    )
                ) {
                    popUpTo(playbackRootRoute) { inclusive = true }
                }
            }

            PlayerScreen(
                onBackPress = { currentVideoId, currentSeason, currentEpisode, autoPlayEnabled, playbackCompleted ->
                    val args = backStackEntry.arguments
                    // Live TV fork: a recording goes back to Recordings (it has no details page).
                    if (com.nuvio.tv.livetv.record.RecordingResume.isRecording(args?.getString("contentType"))) {
                        navController.popBackStack()
                        return@PlayerScreen
                    }
                    val initialSeason = args?.getString("season")?.toIntOrNull()
                    val initialEpisode = args?.getString("episode")?.toIntOrNull()
                    val episodeChangedInPlace = (currentSeason != null || currentEpisode != null) &&
                        (currentSeason != initialSeason || currentEpisode != initialEpisode)
                    val returnToDetailOnBack = args?.getString("returnToDetailOnBack")
                        ?.toBooleanStrictOrNull() == true
                    val returnToHomeOnBack = args?.getString("returnToHomeOnBack")
                        ?.toBooleanStrictOrNull() == true
                    val contentType = args?.getString("contentType").orEmpty()
                    val contentId = args?.getString("contentId").orEmpty()
                    val focusSeason = currentSeason ?: initialSeason
                    val focusEpisode = currentEpisode ?: initialEpisode
                    fun returnToDetail() {
                        val detailEntry = navController.currentBackStack.value
                            .lastOrNull {
                                val itemId = it.arguments?.getString("itemId").orEmpty()
                                val itemType = it.arguments?.getString("itemType").orEmpty()
                                it.destination.route?.startsWith("detail/") == true &&
                                    itemId == contentId &&
                                    (itemType.isBlank() || contentType.isBlank() || itemType.equals(contentType, ignoreCase = true))
                            }
                        if (detailEntry != null) {
                            detailEntry.savedStateHandle["returnFocusSeason"] = focusSeason
                            detailEntry.savedStateHandle["returnFocusEpisode"] = focusEpisode
                            navController.popBackStack(Screen.Detail.route, inclusive = false)
                        } else {
                            navController.navigate(
                                Screen.Detail.createRoute(
                                    itemId = contentId,
                                    itemType = contentType,
                                    addonBaseUrl = null,
                                    returnFocusSeason = focusSeason,
                                    returnFocusEpisode = focusEpisode,
                                    returnToHomeOnBack = returnToHomeOnBack,
                                    heroBackdropUrl = args?.getString("backdrop")
                                )
                            ) {
                                popUpTo(Screen.Player.route) { inclusive = true }
                                launchSingleTop = true
                            }
                        }
                    }

                    when {
                        playbackCompleted && contentId.isNotBlank() -> {
                            returnToDetail()
                        }
                        episodeChangedInPlace && autoPlayEnabled -> {
                            // autoplay moved to next episode — skip Stream, go to detail
                            if (returnToDetailOnBack && contentType.equals("series", ignoreCase = true) && contentId.isNotBlank()) {
                                returnToDetail()
                            } else {
                                navController.popBackStack()
                            }
                        }
                        playerBackOpensCurrentEpisodeStreams(episodeChangedInPlace, autoPlayEnabled) -> {
                            // manual stream switch to next episode — go to Stream of current episode
                            val videoId = currentVideoId ?: args?.getString("videoId").orEmpty()
                            if (videoId.isNotBlank() && contentType.isNotBlank()) {
                                navController.navigate(
                                    Screen.Stream.createRoute(
                                        videoId = videoId,
                                        contentType = contentType,
                                        title = args?.getString("title").orEmpty(),
                                        poster = args?.getString("poster"),
                                        backdrop = args?.getString("backdrop"),
                                        logo = args?.getString("logo"),
                                        season = focusSeason,
                                        episode = focusEpisode,
                                        year = args?.getString("year"),
                                        contentId = contentId.takeIf { it.isNotBlank() },
                                        contentName = args?.getString("contentName"),
                                        manualSelection = true,
                                        returnToDetailOnBack = returnToDetailOnBack,
                                        returnToHomeOnBack = returnToHomeOnBack,
                                        profileId = args?.getString("profileId")?.toIntOrNull()
                                    )
                                ) {
                                    popUpTo(Screen.Stream.route) { inclusive = true }
                                    launchSingleTop = true
                                }
                            } else {
                                navController.popBackStack()
                            }
                        }
                        else -> {
                            val returnedToStream = popBackToStream()
                            if (!returnedToStream) {
                                if (returnToDetailOnBack && contentType.equals("series", ignoreCase = true) && contentId.isNotBlank()) {
                                    returnToDetail()
                                } else {
                                    navController.popBackStack()
                                }
                            }
                        }
                    }
                },
                onPlaybackEnded = { nextVideoId, nextSeason, nextEpisode, exitReason ->
                    val args = backStackEntry.arguments
                    // Live TV fork: a recording that finishes goes back to Recordings.
                    if (com.nuvio.tv.livetv.record.RecordingResume.isRecording(args?.getString("contentType"))) {
                        navController.popBackStack()
                        return@PlayerScreen
                    }
                    val contentType = args?.getString("contentType").orEmpty()
                    val contentId = args?.getString("contentId").orEmpty()
                    val returnToDetailOnBack = args?.getString("returnToDetailOnBack")
                        ?.toBooleanStrictOrNull() == true
                    val returnToHomeOnBack = args?.getString("returnToHomeOnBack")
                        ?.toBooleanStrictOrNull() == true
                    if (nextVideoId != null && nextSeason != null && nextEpisode != null) {
                        val route = Screen.Stream.createRoute(
                            videoId = nextVideoId,
                            contentType = contentType,
                            title = args?.getString("title").orEmpty(),
                            poster = args?.getString("poster"),
                            backdrop = args?.getString("backdrop"),
                            logo = args?.getString("logo"),
                            season = nextSeason,
                            episode = nextEpisode,
                            episodeName = null,
                            genres = null,
                            year = args?.getString("year"),
                            contentId = contentId.takeIf { it.isNotBlank() },
                            contentName = args?.getString("contentName"),
                            runtime = null,
                            returnToDetailOnBack = returnToDetailOnBack,
                            returnToHomeOnBack = returnToHomeOnBack,
                            profileId = args?.getString("profileId")?.toIntOrNull()
                        )
                        navController.navigate(route) {
                            popUpTo(Screen.Player.route) { inclusive = true }
                        }
                    } else {
                        if (exitReason == PlayerExitReason.StillWatchingPrompt) {
                            val detailEntry = navController.currentBackStack.value
                                .lastOrNull { it.destination.route?.startsWith("detail/") == true }
                            if (detailEntry != null) {
                                detailEntry.savedStateHandle["returnFocusSeason"] = null
                                detailEntry.savedStateHandle["returnFocusEpisode"] = null
                                val token = (detailEntry.savedStateHandle.get<Int>("heroRestoreToken") ?: 0) + 1
                                detailEntry.savedStateHandle["heroRestoreToken"] = token
                                navController.popBackStack(Screen.Detail.route, inclusive = false)
                            } else {
                                val contentId = args?.getString("contentId").orEmpty()
                                val contentType = args?.getString("contentType").orEmpty()
                                val returnToHomeOnBack = args?.getString("returnToHomeOnBack")
                                    ?.toBooleanStrictOrNull() == true
                                if (contentId.isNotBlank()) {
                                    navController.navigate(
                                        Screen.Detail.createRoute(
                                            itemId = contentId,
                                            itemType = contentType,
                                            addonBaseUrl = null,
                                            returnToHomeOnBack = returnToHomeOnBack,
                                            heroBackdropUrl = args?.getString("backdrop")
                                        )
                                    ) {
                                        popUpTo(Screen.Player.route) { inclusive = true }
                                        launchSingleTop = true
                                    }
                                } else {
                                    val poppedToStream = navController.popBackStack(Screen.Stream.route, inclusive = true)
                                    if (!poppedToStream) {
                                        navController.popBackStack()
                                    }
                                }
                            }
                        } else {
                            val contentId = args?.getString("contentId").orEmpty()
                            val contentType = args?.getString("contentType").orEmpty()
                            val returnToHomeOnBack = args?.getString("returnToHomeOnBack")
                                ?.toBooleanStrictOrNull() == true
                            val focusSeason = args?.getString("season")?.toIntOrNull()
                            val focusEpisode = args?.getString("episode")?.toIntOrNull()
                            if (contentId.isNotBlank()) {
                                val detailEntry = navController.currentBackStack.value
                                    .lastOrNull {
                                        val itemId = it.arguments?.getString("itemId").orEmpty()
                                        val itemType = it.arguments?.getString("itemType").orEmpty()
                                        it.destination.route?.startsWith("detail/") == true &&
                                            itemId == contentId &&
                                            (itemType.isBlank() || contentType.isBlank() || itemType.equals(contentType, ignoreCase = true))
                                    }
                                if (detailEntry != null) {
                                    detailEntry.savedStateHandle["returnFocusSeason"] = focusSeason
                                    detailEntry.savedStateHandle["returnFocusEpisode"] = focusEpisode
                                    navController.popBackStack(Screen.Detail.route, inclusive = false)
                                } else {
                                    navController.navigate(
                                        Screen.Detail.createRoute(
                                            itemId = contentId,
                                            itemType = contentType,
                                            addonBaseUrl = null,
                                            returnFocusSeason = focusSeason,
                                            returnFocusEpisode = focusEpisode,
                                            returnToHomeOnBack = returnToHomeOnBack,
                                            heroBackdropUrl = args?.getString("backdrop")
                                        )
                                    ) {
                                        popUpTo(Screen.Player.route) { inclusive = true }
                                        launchSingleTop = true
                                    }
                                }
                            } else {
                                val poppedToStream = navController.popBackStack(Screen.Stream.route, inclusive = true)
                                if (!poppedToStream) {
                                    navController.popBackStack()
                                }
                            }
                        }
                    }
                },
                onPlayRecommendation = { recommendation, manualSelection ->
                    navigateFromPostPlay(
                        recommendation = recommendation,
                        playOnLoad = true,
                        manualSelection = manualSelection
                    )
                },
                onOpenRecommendationDetails = { recommendation ->
                    navigateFromPostPlay(
                        recommendation = recommendation,
                        playOnLoad = false
                    )
                },
                onOpenPartyMedia = ::openPartyMedia,
                onPlaybackErrorBack = {
                    val returnedToStream = popBackToStream()
                    if (!returnedToStream) {
                        val args = backStackEntry.arguments
                        val videoId = args?.getString("videoId").orEmpty()
                        val contentType = args?.getString("contentType").orEmpty()
                        val title = args?.getString("title").orEmpty()

                        if (videoId.isBlank() || contentType.isBlank() || title.isBlank()) {
                            navController.popBackStack()
                        } else {
                            val route = Screen.Stream.createRoute(
                                videoId = videoId,
                                contentType = contentType,
                                title = title,
                                poster = args?.getString("poster"),
                                backdrop = args?.getString("backdrop"),
                                logo = args?.getString("logo"),
                                season = args?.getString("season")?.toIntOrNull(),
                                episode = args?.getString("episode")?.toIntOrNull(),
                                episodeName = args?.getString("episodeTitle"),
                                genres = null,
                                year = args?.getString("year"),
                                contentId = args?.getString("contentId"),
                                contentName = args?.getString("contentName"),
                                runtime = null,
                                manualSelection = true,
                                returnToDetailOnBack = args?.getString("returnToDetailOnBack")
                                    ?.toBooleanStrictOrNull() == true,
                                returnToHomeOnBack = args?.getString("returnToHomeOnBack")
                                    ?.toBooleanStrictOrNull() == true,
                                profileId = args?.getString("profileId")?.toIntOrNull()
                            )

                            navController.navigate(route) {
                                popUpTo(Screen.Player.route) { inclusive = true }
                                launchSingleTop = true
                            }
                        }
                    }
                }
            )
        }

        composable(Screen.Search.route) { backStackEntry ->
            val searchViewModel: com.nuvio.tv.ui.screens.search.SearchViewModel =
                androidx.hilt.navigation.compose.hiltViewModel(backStackEntry)
            SearchScreen(
                viewModel = searchViewModel,
                // Live TV fork: the On Demand row (your provider's own titles).
                onOpenOnDemand = { itemId, itemType, addonBaseUrl, onDemandUid ->
                    navController.navigate(Screen.Detail.createRoute(itemId, itemType, addonBaseUrl))
                    navController.currentBackStackEntry?.savedStateHandle?.set(
                        com.nuvio.tv.livetv.ondemand.OnDemandPlay.KEY, onDemandUid
                    )
                },
                onPlayOnDemand = { url, title, type, poster ->
                    navController.navigate(
                        Screen.Player.createRoute(
                            streamUrl = url,
                            title = title,
                            contentType = type,
                            contentName = title,
                            poster = poster,
                            addonName = com.nuvio.tv.livetv.ondemand.OnDemandStreams.GROUP_NAME
                        )
                    )
                },
                onOpenLiveTv = {
                    // Put the guide underneath, so Back from full screen lands on the guide
                    // with this channel highlighted (not back in search).
                    navController.navigate(Screen.LiveTv.route) {
                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                    navController.navigate(Screen.LiveTvPlayer.route) { launchSingleTop = true }
                },
                onNavigateToDetail = { itemId, itemType, addonBaseUrl ->
                    val heroBackdrop = HeroBackdropState.consumeAndClear()
                    navController.navigate(
                        Screen.Detail.createRoute(
                            itemId = itemId,
                            itemType = itemType,
                            addonBaseUrl = addonBaseUrl,
                            heroBackdropUrl = heroBackdrop
                        )
                    )
                },
                onNavigateToSeeAll = { catalogId, addonId, type ->
                    navController.navigate(
                        Screen.CatalogSeeAll.createRoute(catalogId, addonId, type, fromSearch = true)
                    )
                },
                onOpenDiscover = { navController.navigate(Screen.Discover.route) }
            )
        }

        composable(Screen.Discover.route) {
            DiscoverScreen(
                showBuiltInHeader = !hideBuiltInHeaders,
                onNavigateToDetail = { itemId, itemType, addonBaseUrl ->
                    val heroBackdrop = HeroBackdropState.consumeAndClear()
                    navController.navigate(
                        Screen.Detail.createRoute(
                            itemId = itemId,
                            itemType = itemType,
                            addonBaseUrl = addonBaseUrl,
                            heroBackdropUrl = heroBackdrop
                        )
                    )
                }
            )
        }

        composable(Screen.Library.route) {
            LibraryScreen(
                showBuiltInHeader = !hideBuiltInHeaders,
                onNavigateToDetail = { itemId, itemType, addonBaseUrl ->
                    navController.navigate(Screen.Detail.createRoute(itemId, itemType, addonBaseUrl))
                },
                onNavigateToCatalogSeeAll = { catalogId, addonId, type ->
                    navController.navigate(Screen.CatalogSeeAll.createRoute(catalogId, addonId, type))
                },
                onCloudPlaybackResolved = { info ->
                    val filename = info.filename ?: info.file.name
                    navController.navigate(
                        Screen.Player.createRoute(
                            streamUrl = info.url,
                            title = filename,
                            streamName = filename,
                            contentType = "cloud",
                            contentName = info.item.name,
                            videoId = "${info.item.stableKey}:${info.file.stableKey}",
                            season = 1,
                            episode = info.sequenceIndex + 1,
                            episodeTitle = filename,
                            filename = filename,
                            videoSize = info.videoSizeBytes,
                            addonName = info.item.providerName,
                            streamDescription = info.item.name,
                            cloudSessionToken = info.sessionToken
                        )
                    )
                }
            )
        }

        composable(Screen.LiveTv.route) {
            com.nuvio.tv.livetv.ui.LiveTvGuideScreen(
                onOpenFullscreen = {
                    navController.navigate(Screen.LiveTvPlayer.route) { launchSingleTop = true }
                },
                onOpenSettings = { navController.navigate(Screen.LiveTvSettings.route) },
                // Recordings opens from the guide now (Back comes back to the guide).
                onOpenRecordings = { navController.navigate(Screen.Recordings.route) { launchSingleTop = true } },
                onFindInNuvio = {
                    // Back from search returns to the guide.
                    navController.navigate(Screen.Search.route) { launchSingleTop = true }
                },
                onReturnToSports = {
                    navController.navigate(Screen.Sports.route) {
                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }

        composable(Screen.Recordings.route) {
            // Live TV fork: recorded shows, played in Nuvio's own player.
            com.nuvio.tv.livetv.record.RecordingsScreen(
                onPlay = { url, title, poster, recordingId, fromStart ->
                    navController.navigate(
                        Screen.Player.createRoute(
                            streamUrl = url,
                            title = title,
                            // Its own kind, so the player keeps its place for next time but leaves
                            // it out of Continue Watching, watch history and Trakt.
                            contentId = com.nuvio.tv.livetv.record.RecordingResume.contentIdFor(recordingId),
                            contentType = com.nuvio.tv.livetv.record.RecordingResume.CONTENT_TYPE,
                            contentName = title,
                            poster = poster,
                            startFromBeginning = fromStart,
                            addonName = "Recordings"
                        )
                    )
                }
            )
        }

        composable(Screen.Calendar.route) {
            // Live TV fork: when your shows' new episodes and your movies come out.
            com.nuvio.tv.livetv.calendar.CalendarScreen(
                onOpenDetail = { id, type, addonBaseUrl, season, episode ->
                    navController.navigate(
                        Screen.Detail.createRoute(
                            itemId = id,
                            itemType = type,
                            addonBaseUrl = addonBaseUrl,
                            returnFocusSeason = season,
                            returnFocusEpisode = episode
                        )
                    )
                },
                onFindSources = { e ->
                    val videoId = e.videoId
                    if (videoId != null) {
                        navController.navigate(
                            Screen.Stream.createRoute(
                                videoId = videoId,
                                contentType = "series",
                                title = e.title,
                                poster = e.poster,
                                backdrop = e.background,
                                season = e.season,
                                episode = e.episode,
                                episodeName = e.episodeTitle,
                                contentId = e.contentId,
                                contentName = e.title,
                                runtime = e.runtimeMin
                            )
                        )
                    }
                },
                onOpenLive = { com.nuvio.tv.livetv.sports.openLiveTvFullscreen(navController) },
                onOpenGame = { id ->
                    com.nuvio.tv.livetv.sports.SportsLaunch.openEvent(id)
                    navController.navigate(Screen.Sports.route) { launchSingleTop = true }
                }
            )
        }

        composable(Screen.Sports.route) {
            // Live TV fork: the Sports page (scores, schedules, which of your channels show each game).
            com.nuvio.tv.livetv.sports.SportsScreen(
                onOpenLive = { com.nuvio.tv.livetv.sports.openLiveTvFullscreen(navController) }
            )
        }

        composable(Screen.OnDemand.route) {
            // Live TV fork: On Demand in Nuvio's own home layout (Classic, Grid or Modern, as set
            // for Home), with every layout option taken from Home itself.
            // Home's settings, read safely: Home may not be in the history (it's removed when the
            // side menu switches pages and a profile picker is the start), and a removed Home
            // must never be touched (that crashed the app, often on Back). Looked up afresh each
            // time, used only while alive; otherwise the last settings Home had are used.
            val homeEntry = runCatching { navController.getBackStackEntry(Screen.Home.route) }.getOrNull()
                ?.takeIf { it.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.CREATED) }
            val homeVm: com.nuvio.tv.ui.screens.home.HomeViewModel? = homeEntry?.let { androidx.hilt.navigation.compose.hiltViewModel(it) }
            // Only Home's settings (layout, poster size…), not its rows: Home loading or updating
            // its own rows in the background must not rebuild this page.
            val homeSettingsFlow = androidx.compose.runtime.remember(homeVm) {
                homeVm?.uiState?.map { it.settingsOnly() }?.distinctUntilChanged()
            }
            val homeSettings = homeSettingsFlow?.collectAsStateWithLifecycle(initialValue = null)?.value
                ?.also { com.nuvio.tv.livetv.ondemand.OnDemandHomeSettings.last = it }
                ?: com.nuvio.tv.livetv.ondemand.OnDemandHomeSettings.last?.settingsOnly()
            com.nuvio.tv.livetv.ondemand.OnDemandHomeScreen(
                homeSettings = homeSettings,
                onOpenDetail = { itemId, itemType, addonBaseUrl, onDemandUid ->
                    navController.navigate(Screen.Detail.createRoute(itemId, itemType, addonBaseUrl))
                    navController.currentBackStackEntry?.savedStateHandle?.set(
                        com.nuvio.tv.livetv.ondemand.OnDemandPlay.KEY, onDemandUid
                    )
                },
                onPlay = { url, title, type, poster ->
                    navController.navigate(
                        Screen.Player.createRoute(
                            streamUrl = url,
                            title = title,
                            contentType = type,
                            contentName = title,
                            poster = poster,
                            addonName = com.nuvio.tv.livetv.ondemand.OnDemandStreams.GROUP_NAME
                        )
                    )
                },
                // Search goes to Nuvio's own search (results open the usual details page, where
                // your provider's copies are offered too).
                onOpenSearch = {
                    // What this search shows is set for On Demand in Live TV settings.
                    com.nuvio.tv.livetv.ui.LiveTvSearchBridge.origin.value = com.nuvio.tv.livetv.ui.LiveTvSearchBridge.ON_DEMAND
                    navController.navigate(Screen.Search.route) { launchSingleTop = true }
                }
            )
        }

        composable(Screen.LiveTvPlayer.route) {
            // Live TV fork: full screen now happens inside the guide (one video view that just
            // grows), so this route hands over to the guide in full screen.
            androidx.compose.runtime.LaunchedEffect(Unit) {
                com.nuvio.tv.livetv.ui.LiveTvFullscreen.request()
                if (!navController.popBackStack(Screen.LiveTv.route, inclusive = false)) {
                    navController.navigate(Screen.LiveTv.route) {
                        popUpTo(Screen.LiveTvPlayer.route) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            }
        }

        composable(Screen.LiveTvSettings.route) {
            com.nuvio.tv.ui.screens.settings.LiveTvSettingsScreen(
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                showBuiltInHeader = !hideBuiltInHeaders,
                onNavigateToLiveTv = { navController.navigate(Screen.LiveTvSettings.route) },
                onNavigateToSportsTeams = {
                    com.nuvio.tv.livetv.sports.SportsLaunch.openPicker()
                    navController.navigate(Screen.Sports.route) {
                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToAddons = { navController.navigate(Screen.AddonManager.route) },
                onNavigateToPlugins = { navController.navigate(Screen.Plugins.route) },
                onNavigateToAuthQrSignIn = { navController.navigate(Screen.AuthQrSignIn.route) },
                onNavigateToManageProfiles = { navController.navigate(Screen.ManageProfiles.route) },
                onNavigateToSupportersContributors = {
                    navController.navigate(Screen.SupportersContributors.route)
                },
                onNavigateToLicensesAttributions = {
                    navController.navigate(Screen.LicensesAttributions.route)
                },
                onNavigateToWatchParty = { navController.navigate(Screen.WatchParty.createRoute()) }
            )
        }

        composable(
            route = Screen.WatchParty.route,
            arguments = listOf(
                navArgument("code") {
                    type = NavType.StringType
                    defaultValue = ""
                }
            )
        ) { backStackEntry ->
            PartyScreen(
                initialCode = backStackEntry.arguments?.getString("code").orEmpty(),
                onBackPress = { navController.popBackStack() },
                onWatch = ::openPartyMedia
            )
        }

        composable(Screen.ManageProfiles.route) {
            ProfileSelectionScreen(
                onProfileSelected = {},
                screenMode = ProfileSelectionMode.Management,
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.Tracking.route) {
            TrackingSettingsScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.TmdbSettings.route) {
            TmdbSettingsScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.ThemeSettings.route) {
            ThemeSettingsScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.PlaybackSettings.route) {
            PlaybackSettingsScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.About.route) {
            AboutScreen(
                onBackPress = { navController.popBackStack() },
                onNavigateToSupportersContributors = {
                    navController.navigate(Screen.SupportersContributors.route)
                },
                onNavigateToLicensesAttributions = {
                    navController.navigate(Screen.LicensesAttributions.route)
                }
            )
        }

        if (AppFeaturePolicy.supportNuvioEnabled) {
            composable(Screen.SupportersContributors.route) {
                SupportersContributorsScreen(
                    onBackPress = { navController.popBackStack() }
                )
            }
        }

        composable(Screen.LicensesAttributions.route) {
            LicensesAttributionsScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.AddonManager.route) {
            AddonManagerScreen(
                showBuiltInHeader = !hideBuiltInHeaders,
                onBackPress = { navController.popBackStack() },
                onNavigateToCatalogOrder = { navController.navigate(Screen.CatalogOrder.route) },
                onNavigateToCollections = { navController.navigate(Screen.Collections.route) }
            )
        }

        composable(Screen.CatalogOrder.route) {
            CatalogOrderScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.Collections.route) {
            com.nuvio.tv.ui.screens.collection.CollectionManagementScreen(
                onNavigateToEditor = { collectionId ->
                    navController.navigate(Screen.CollectionEditor.createRoute(collectionId))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.CollectionEditor.route,
            arguments = listOf(
                navArgument("collectionId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) {
            com.nuvio.tv.ui.screens.collection.CollectionEditorScreen(
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.FolderDetail.route,
            arguments = listOf(
                navArgument("collectionId") { type = NavType.StringType },
                navArgument("folderId") { type = NavType.StringType }
            )
        ) {
            com.nuvio.tv.ui.screens.collection.FolderDetailScreen(
                onNavigateToDetail = { itemId, itemType, addonBaseUrl ->
                    val heroBackdrop = HeroBackdropState.consumeAndClear()
                    navController.navigate(Screen.Detail.createRoute(itemId, itemType, addonBaseUrl, heroBackdropUrl = heroBackdrop))
                },
                onBack = { navController.popBackStack() }
            )
        }

        if (AppFeaturePolicy.pluginsEnabled) {
            composable(Screen.Plugins.route) {
                PluginScreen(
                    onBackPress = { navController.popBackStack() }
                )
            }
        }

        composable(Screen.Account.route) {
            AuthQrSignInScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.AuthSignIn.route) {
            AuthQrSignInScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.AuthQrSignIn.route) {
            AuthQrSignInScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(Screen.LayoutSettings.route) {
            LayoutSettingsScreen(
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.CatalogSeeAll.route,
            arguments = listOf(
                navArgument("catalogId") { type = NavType.StringType },
                navArgument("addonId") { type = NavType.StringType },
                navArgument("type") { type = NavType.StringType },
                navArgument("fromSearch") {
                    type = NavType.BoolType
                    defaultValue = false
                }
            )
        ) { backStackEntry ->
            val catalogId = backStackEntry.arguments?.getString("catalogId") ?: ""
            val addonId = backStackEntry.arguments?.getString("addonId") ?: ""
            val type = backStackEntry.arguments?.getString("type") ?: ""
            val fromSearch = backStackEntry.arguments?.getBoolean("fromSearch") ?: false
            if (ServerCatalog.isServerAddonId(addonId) && !fromSearch) {
                ServerCatalogDestination(navController, backStackEntry)
                return@composable
            }

            // When coming from search, get the SearchViewModel from the Search back stack entry
            // so we share the same data (existing results + pagination)
            val searchBackStackEntry = androidx.compose.runtime.remember(fromSearch) {
                if (fromSearch) {
                    try { navController.getBackStackEntry(Screen.Search.route) } catch (_: Exception) { null }
                } else null
            }
            val searchViewModel: com.nuvio.tv.ui.screens.search.SearchViewModel? =
                if (searchBackStackEntry != null) {
                    androidx.hilt.navigation.compose.hiltViewModel<com.nuvio.tv.ui.screens.search.SearchViewModel>(searchBackStackEntry)
                } else null
            val homeBackStackEntry = androidx.compose.runtime.remember {
                try { navController.getBackStackEntry(Screen.Home.route) } catch (_: Exception) { null }
            }
            val homeViewModel: com.nuvio.tv.ui.screens.home.HomeViewModel =
                if (homeBackStackEntry != null) {
                    androidx.hilt.navigation.compose.hiltViewModel(homeBackStackEntry)
                } else {
                    androidx.hilt.navigation.compose.hiltViewModel(backStackEntry)
                }

            CatalogSeeAllScreen(
                catalogId = catalogId,
                addonId = addonId,
                type = type,
                searchViewModel = searchViewModel,
                viewModel = homeViewModel,
                onNavigateToDetail = { itemId, itemType, addonBaseUrl ->
                    navController.navigate(Screen.Detail.createRoute(itemId, itemType, addonBaseUrl))
                },
                onBackPress = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.CastDetail.route,
            arguments = listOf(
                navArgument("personId") { type = NavType.StringType },
                navArgument("personName") { type = NavType.StringType },
                navArgument("preferCrew") {
                    type = NavType.BoolType
                    defaultValue = false
                }
            )
        ) {
            CastDetailScreen(
                onBackPress = { navController.popBackStack() },
                onNavigateToDetail = { itemId, itemType, addonBaseUrl ->
                    navController.navigate(Screen.Detail.createRoute(itemId, itemType, addonBaseUrl))
                }
            )
        }

        composable(
            route = Screen.TmdbEntityBrowse.route,
            arguments = listOf(
                navArgument("entityKind") { type = NavType.StringType },
                navArgument("entityId") { type = NavType.IntType },
                navArgument("entityName") { type = NavType.StringType },
                navArgument("sourceType") {
                    type = NavType.StringType
                    defaultValue = "tv"
                }
            )
        ) {
            TmdbEntityBrowseScreen(
                onBackPress = { navController.popBackStack() },
                onNavigateToDetail = { itemId, itemType, addonBaseUrl ->
                    navController.navigate(Screen.Detail.createRoute(itemId, itemType, addonBaseUrl))
                }
            )
        }
    }
}
